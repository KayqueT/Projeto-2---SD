`timescale 1ns/1ps

module lcd_controller (
    input  wire        clk,                 // Clock da placa (50 MHz)
    input  wire        reset,               // Reset assíncrono
    input  wire        iniciar,             // Pulso para iniciar nova escrita
    input  wire [2:0]  opcode,              // Opcode da instrução executada
    input  wire [3:0]  registrador_destino, // Número do reg de destino (0–15)
    input  wire [15:0] valor_resultado,     // Valor a exibir (com sinal)

    output reg  [7:0]  lcd_dados,           // Barramento de dados D7–D0
    output reg         lcd_rs,              // Register Select: 0=cmd, 1=dado
    output reg         lcd_rw,              // Read/Write: sempre 0 (escrita)
    output reg         lcd_en,              // Enable (negedge dispara LCD)
    output reg         lcd_ligado           // Indica se o display está ativo
);

    // MANTIDO: 1 ms exato = 50.000 ciclos a 50 MHz
    localparam ESPERA_MS = 50_000;

    // Estados da máquina de estados do controlador
    localparam [3:0]
        EST_OCIOSO        = 4'd0,   
        EST_INIT_1        = 4'd1,   
        EST_INIT_2        = 4'd2,   
        EST_INIT_3        = 4'd3,   
        EST_INIT_4        = 4'd4,   
        EST_LINHA1_POS    = 4'd5,   
        EST_ESCREVE_L1    = 4'd6,   
        EST_LINHA2_POS    = 4'd7,   
        EST_ESCREVE_L2    = 4'd8,   
        EST_ESPERA        = 4'd9,   
        EST_DESLIGADO     = 4'd10;  

    // Opcodes
    localparam OP_LOAD    = 3'b000;
    localparam OP_ADD     = 3'b001;
    localparam OP_ADDI    = 3'b010;
    localparam OP_SUB     = 3'b011;
    localparam OP_SUBI    = 3'b100;
    localparam OP_MUL     = 3'b101;
    localparam OP_CLEAR   = 3'b110;
    localparam OP_DISPLAY = 3'b111;

    reg [3:0]  estado_atual, proximo_estado;
    reg [3:0]  indice_char;     
    reg [7:0]  linha1 [0:15];
    reg [7:0]  linha2 [0:15];
    reg [3:0]  reg_indice; 

    integer k;

    // Função auxiliar: converte dígito (0–9) em ASCII
    function [7:0] digito_ascii;
        input [3:0] digito;
        begin
            digito_ascii = 8'h30 + {4'b0, digito}; 
        end
    endfunction

    // Conversão do valor resultado para BCD
    reg [15:0] valor_abs;      
    reg        valor_negativo; 
    reg [3:0]  bcd_milhar, bcd_centena, bcd_dezena, bcd_unidade, bcd_dez_milhar;

    always @(*) begin
        valor_negativo = valor_resultado[15]; 
        valor_abs      = valor_negativo ? (~valor_resultado + 1'b1) : valor_resultado;

        bcd_dez_milhar = (valor_abs / 10000) % 10;
        bcd_milhar     = (valor_abs / 1000)  % 10;
        bcd_centena    = (valor_abs / 100)   % 10;
        bcd_dezena     = (valor_abs / 10)    % 10;
        bcd_unidade    =  valor_abs          % 10;
    end

    // Montagem das linhas do LCD
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            for (k = 0; k < 16; k = k + 1) begin
                linha1[k] <= 8'h20; 
                linha2[k] <= 8'h20;
            end
        end
        else if (iniciar) begin
            linha2[0] <= valor_negativo ? 8'h2D : 8'h2B; 
            linha2[1] <= digito_ascii(bcd_dez_milhar);
            linha2[2] <= digito_ascii(bcd_milhar);
            linha2[3] <= digito_ascii(bcd_centena);
            linha2[4] <= digito_ascii(bcd_dezena);
            linha2[5] <= digito_ascii(bcd_unidade);
            linha2[6] <= 8'h20; linha2[7]  <= 8'h20;
            linha2[8] <= 8'h20; linha2[9]  <= 8'h20;
            linha2[10]<= 8'h20; linha2[11] <= 8'h20;
            linha2[12]<= 8'h20; linha2[13] <= 8'h20;
            linha2[14]<= 8'h20; linha2[15] <= 8'h20;

            case (opcode)
                OP_ADD: begin
                    linha1[0]<=8'h41; linha1[1]<=8'h44; 
                    linha1[2]<=8'h44; linha1[3]<=8'h20; 
                end
                OP_ADDI: begin
                    linha1[0]<=8'h41; linha1[1]<=8'h44; 
                    linha1[2]<=8'h44; linha1[3]<=8'h49; 
                end
                OP_SUB: begin
                    linha1[0]<=8'h53; linha1[1]<=8'h55; 
                    linha1[2]<=8'h42; linha1[3]<=8'h20; 
                end
                OP_SUBI: begin
                    linha1[0]<=8'h53; linha1[1]<=8'h55; 
                    linha1[2]<=8'h42; linha1[3]<=8'h49; 
                end
                OP_MUL: begin
                    linha1[0]<=8'h4D; linha1[1]<=8'h55; 
                    linha1[2]<=8'h4C; linha1[3]<=8'h20; 
                end
                OP_LOAD: begin
                    linha1[0]<=8'h4C; linha1[1]<=8'h4F; 
                    linha1[2]<=8'h41; linha1[3]<=8'h44; 
                end
                OP_CLEAR: begin
                    linha1[0]<=8'h43; linha1[1]<=8'h4C; 
                    linha1[2]<=8'h52; linha1[3]<=8'h20; 
                end
                OP_DISPLAY: begin
                    linha1[0]<=8'h44; linha1[1]<=8'h50; 
                    linha1[2]<=8'h4C; linha1[3]<=8'h20; 
                end
                default: begin
                    linha1[0]<=8'h3F; linha1[1]<=8'h3F; 
                    linha1[2]<=8'h3F; linha1[3]<=8'h20;
                end
            endcase

            linha1[4] <= 8'h20; linha1[5] <= 8'h20;
            linha1[6]  <= 8'h5B; // '['
            linha1[7]  <= registrador_destino[3] ? 8'h31 : 8'h30; 
            linha1[8]  <= registrador_destino[2] ? 8'h31 : 8'h30; 
            linha1[9]  <= registrador_destino[1] ? 8'h31 : 8'h30; 
            linha1[10] <= registrador_destino[0] ? 8'h31 : 8'h30; 
            linha1[11] <= 8'h5D; // ']'
            linha1[12] <= 8'h20; linha1[13] <= 8'h20;
            linha1[14] <= 8'h20; linha1[15] <= 8'h20;
        end
    end

    // Máquina de estados
    always @(posedge clk or posedge reset) begin
        if (reset)
            estado_atual <= EST_INIT_1;
        else
            estado_atual <= proximo_estado;
    end

    // Contador de espera (redimensionado para 16 bits, ideal para 50.000)
    reg [15:0] cnt_espera; 
    always @(posedge clk or posedge reset) begin
        if (reset)
            cnt_espera <= 0;
        else if (estado_atual != proximo_estado)
            cnt_espera <= 0;
        else
            cnt_espera <= cnt_espera + 1;
    end

    // Lógica de transição e saídas combinacionais
    always @(*) begin
        proximo_estado = estado_atual;
        lcd_rs   = 1'b0;
        lcd_rw   = 1'b0;
        lcd_en   = 1'b0;
        lcd_dados= 8'h00;
        lcd_ligado = 1'b1;
        
        // FIX: Mapeamento dinâmico do índice ativo para ler a string corretamente
        indice_char = reg_indice; 

        case (estado_atual)

            EST_INIT_1: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'b0011_1000; 
                // FIX: Pulso HIGH estendido para 30 ciclos (600 ns) para respeitar o mínimo físico de 450 ns do LCD
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) proximo_estado = EST_INIT_2;
            end

            EST_INIT_2: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'b0000_1100; 
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) proximo_estado = EST_INIT_3;
            end

            EST_INIT_3: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'b0000_0110; 
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) proximo_estado = EST_INIT_4;
            end

            EST_INIT_4: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'b0000_0001; 
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) proximo_estado = EST_OCIOSO;
            end

            EST_OCIOSO: begin
                lcd_ligado = 1'b1;
                if (iniciar) proximo_estado = EST_LINHA1_POS;
            end

            EST_LINHA1_POS: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'h80; 
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) proximo_estado = EST_ESCREVE_L1;
            end

            EST_ESCREVE_L1: begin
                lcd_rs    = 1'b1; 
                lcd_dados = linha1[indice_char];
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) begin
                    if (indice_char == 4'd15)
                        proximo_estado = EST_LINHA2_POS;
                end
            end

            EST_LINHA2_POS: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'hC0; 
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) proximo_estado = EST_ESCREVE_L2;
            end

            EST_ESCREVE_L2: begin
                lcd_rs    = 1'b1;
                lcd_dados = linha2[indice_char];
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                if (cnt_espera >= ESPERA_MS) begin
                    if (indice_char == 4'd15)
                        proximo_estado = EST_OCIOSO;
                end
            end

            EST_DESLIGADO: begin
                lcd_rs    = 1'b0;
                lcd_dados = 8'b0000_0001; 
                lcd_en    = (cnt_espera < 30) ? 1'b1 : 1'b0;
                lcd_ligado = 1'b0;
            end

            default: proximo_estado = EST_OCIOSO;
        endcase
    end

    // Controle sequencial do incremento do índice
    always @(posedge clk or posedge reset) begin
        if (reset)
            reg_indice <= 4'd0;
        else if (estado_atual == EST_LINHA1_POS || estado_atual == EST_LINHA2_POS)
            reg_indice <= 4'd0; 
        else if ((estado_atual == EST_ESCREVE_L1 || estado_atual == EST_ESCREVE_L2)
                  && cnt_espera >= ESPERA_MS && reg_indice < 4'd15)
            reg_indice <= reg_indice + 1'b1;
    end
endmodule
module fpga (
    input wire                clk,
    input wire                rst,
    input wire               send,
    input wire [17:0]   switch_bus,

    output wire  [7:0]  lcd_dados,    
    output wire         lcd_rs,    
    output wire         lcd_rw,      
    output wire         lcd_en,        
    output wire         lcd_ligado
);

    wire [2:0]  opcode;
    wire [3:0]  dst;
    wire [15:0] out;
	 wire lcd_enable;

    cpu cpu0(
        .clk(clk),
        .rst(rst),
        .send(send),
        .switch_bus(switch_bus),

		  .lcd(lcd_enable),
        .opcode(opcode),
        .dst(dst),
        .out(out)
    );

    // Fix display
    lcd_controller lcd_ctl0(
		  .clk(clk),
        .reset(rst),                // Ligado ao reset geral do sistema
        .iniciar(lcd_enable),       // O enable da CPU dá a partida (iniciar) no LCD
        .opcode(opcode),
        .registrador_destino(dst), 
        .valor_resultado(out),      

        .lcd_dados(lcd_dados),     
        .lcd_rs(lcd_rs),        
        .lcd_rw(lcd_rw),        
        .lcd_en(lcd_en),        
        .lcd_ligado(lcd_ligado)
    );

endmodule